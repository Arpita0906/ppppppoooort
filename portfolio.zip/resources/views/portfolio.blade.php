<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Arpita Saha - Responsive Personal Portfolio</title>

        <!--box icons-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
        <!--custom css-->
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        
        <link rel="stylesheet" href="{{ url('CSS/portfolio.css')}}">
        
    </head>
    <body>
        
   

        <header class="header">
            <a href="#" class="logo">Portfolio</a>
            
            <nav class="navbar">
                <a href="#" style="--i:1;" class="active">Home</a>
                <a href="#about" style="--i:2;" >About</a>
                <a href="#services" style="--i:3;">Skills</a>
                <a href="#portfolio" style="--i:4;">Portfolio</a>
                <a href="#contact" style="--i:5;">Contact</a>
            </nav>
                <div class="toggle_btn">
                <i class="fa fa-solid fa-bars"></i>
                </div>
                </div>
                <div class="dropdown_menu">
                    <a href="#" style="--i:1;" class="active">Home</a>
                    <a href="#about" style="--i:2;" >About</a>
                    <a href="#services" style="--i:3;">Skills</a>
                    <a href="#portfolio" style="--i:4;">Portfolio</a>
                    <a href="#contact" style="--i:5;">Contact</a>
                </div>
        </header>
        
        <section class="home">
            <div class="home-img2" >
                
                <img src="arpita.jpeg" alt="">
                </div>
            <div class="home-content">
                <h3>Hello, It's Me</h3>
                <h1>Arpita Saha</h1>
                <h3>And I'm a <span id="multiple-text"></span></h3>
                <div class="social-media">
                    <a href="#" style="--i:7;" ><i class='bx bxl-facebook'></i></a>
                    <a href="#" style="--i:8;"><i class='bx bxl-twitter' ></i></a>
                    <a href="#" style="--i:9;"><i class='bx bxl-instagram-alt' ></i></a>
                    <a href="#" style="--i:10;"><i class='bx bxl-linkedin' ></i></a>
                </div>
                <a  class="btn" download>Download Resume</a>
            </div>
            
            <div class="home-img" >
                
                <img src="image/arp.jpg" alt="">
                </div>
        </section>
    

        <!--about section design-->
        
        <section class="about" id="about">
            <h2 class="heading2">About &nbsp<span> Me</span></h2>
            <div class="about-img">
                <img src="https://camo.githubusercontent.com/d77f5b72872906d97a0c5fa4b1ac8368240c1cdef7b5bd13e7aeaa619ad9dc0e/68747470733a2f2f7374617469632e6576656e7473636170652e6c6976652f636d6e2f696d672f636f72702f656e676167655f6275696c645f67726f772e706e67" alt="">
            </div>

            <div class="about-content">
                <h2 class="heading">About <span>Me</span></h2>
                <p>To seek and give my best to a position that offers professional challenges utilizing my technical skills, problem solving skills and communication skills. Keen and motivated to learn and grow ambitious, enthusiastic and eager to contribute team success. 
                    I am looking for exciting roles in the field of software development and engineering.</p>

            </div>
            
        </section>
       
        <!--portfolio section  design-->
        <section class="portfolio" id="portfolio" style="padding-top: 3rem;">
            <h2 class="heading">Latest <span>Project</span></h2>
            <h2 class="headingp2">Latest <span>Project</span></h2>
            <div class="portfolio-container">
                <div class="portfolio-box">
                    <img src="mi.jpeg">
                    <div class="portfolio-layer">
                        <h4>Medical Insurance Cost Predictor </h4>
                        <a href="https://github.com/Arpita0906/Medical_insurance_cost_predictor"><i class='bx bx-link-external' style="color: rgb(34, 250, 250);">LINK</i></a>
                    </div>
                </div>
                <div class="portfolio-box">
                    <img src="ts.jpeg">
                    <div class="portfolio-layer">
                        <h4>Time Sheet Calculator</h4>
                        <a href="https://github.com/Arpita0906/Time-Sheet-Calculator"><i class='bx bx-link-external' style="color: rgb(34, 250, 250);">LINK</i></a>
                    </div>
                </div>
                <div class="portfolio-box">
                    <img src="rrs.jpeg">
                    <div class="portfolio-layer">
                        <h4>Online Railway Commodity Reservation System</h4>
                        <a href="https://github.com/Arpita0906/Online-Railway-Commodity-Reservation"><i class='bx bx-link-external' style="color: rgb(34, 250, 250);">LINK</i></a>
                    </div>
                </div>
                <div class="portfolio-box">
                    <img src="tc.jpeg">
                    <div class="portfolio-layer">
                        <h4>Temperature Converter</h4>
                        <a href="#"><i class='bx bx-link-external' style="color: rgb(34, 250, 250);">LINK</i></a>
                    </div>
                </div>
                <div class="portfolio-box">
                    <img src="landing.jpeg">
                    <div class="portfolio-layer">
                        <h4>Responsive Landing Page </h4>
                        <a href="#"><i class='bx bx-link-external' style="color: rgb(34, 250, 250);">LINK</i></a>
                    </div>
                </div>
            </div>
                
        </section>

        <!--contact section design -->
        <section class="contact" id="contact" style="padding-top: 3rem;">
            <h2 class="heading">Contact <span>Me!</span></h2>
            
            <form action="#">
                <div class="input-box">
                    <input type="text" placeholder="Full Name">
                    <input type="email" placeholder="Email Address">
                </div>
                <div class="input-box">
                    <input type="number" placeholder="Mobile Number">
                    <input type="text" placeholder="Email Subject">
                </div>
                <textarea name="" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
                <input type="submit" value="send Message" class="btn">
            </form>
        </section>

        <!--footer design-->
        <footer class="footer" style="padding-top: 3rem;">
            <div class="footer-text">
                <p>copyright &copy; 2023 by Arpita | All right reserved.</p>

            </div>
            <div class="footer-iconTop">
                <a href="#home"><i class='bx bx-up-arrow-alt'></i></a>
            </div>
        </footer>
        <!--custom js-->
        <script src="https://unpkg.com/typed.js@2.0.15/dist/typed.umd.js"></script>

        <script src="script.js"></script>
        <script>
            var typed=new Typed('#multiple-text',
            {
                strings:['Frontend Devloper','PHP Devloper','Content Writer','Coder','Photographer'],
                typeSpeed:80,
                backSpeed:40,
                backDelay:1000,
                loop:true
            });
        </script>
        

    </body>
</html>