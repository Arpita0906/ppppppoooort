<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('admin', compact('users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'uid'=> 'required',
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password'=> 'required',
        ]);

        User::create($request->all());

        return redirect()->route('admin')->with('success', 'User created successfully.');
    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $user->id,
        ]);

        $user->update($request->all());

        return redirect()->route('admin')->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        $user->delete();

        return redirect()->route('admin')->with('success', 'User deleted successfully.');
    }
}
